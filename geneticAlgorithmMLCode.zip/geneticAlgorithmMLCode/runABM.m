%% run ABM with the optimisation coefficient output
function rmse = runABM(X)
a1 = X(1);
a2 = X(2);
a3 = X(3);
b1 = X(4);
b2 = X(5);
b3 = X(6);
b4 = X(7);
c1 = X(8);
c2 = X(9);
c3 = X(10);
c4 = X(11);
c5 = X(12);
c6 = X(13);
c7 = X(14);
d1 = X(15);
d2 = X(16);
d3 = X(17);
e1 = X(18);
e2 = X(19);
f1 = X(20);
f2 = X(21);
f3 = X(22);
f4 = X(23);
f5 = X(24);
f6 = X(25);
g1 = X(26);
g2 = X(27);
g3 = X(28);
g4 = X(29);
g5 = X(30);
g6 = X(31);


T = X;
dlmwrite('/Users/stephaniekhuu/Documents/MATLAB/tabledata.txt',T,'-append');

% writetable(T,'/Users/stephaniekhuu/Documents/MATLAB/tabledata.txt');

%% Run simulations from matlab

% write the initial batch_params.xml file. Need to be able to change this
% with new inputs from end of simulation

writeBatchParamsFile(a1,a2,a3,b1,b2,b3,b4,c1,c2,c3,c4,c5,c6,...
    c7,d1,d2,d3,e1,e2,f1,f2,f3,f4,f5,f6,g1,g2,g3,g4,g5,g6);

% run the simulation through commandline
try
runABMSimulation();

% retrieve output data (data variable), select only relevant 'dataset',
% select data points at correct times and calculate RMSE between the gold
% dataset and the new data points.
[dataset, data, dataPoints, goldData, rmse] = retrieveOutputData();

%% plot data points
rmseText = strcat('RMSE = ',string(rmse));  % convert rmse to string
txt = rmseText;

figure                                      % make figure

plot (dataPoints(:,1), dataPoints(:,2));    % plot original 
hold on
plot (dataPoints(:,1),dataPoints(:,3));     % vs simulation fibro data

text(400,20,txt,'FontSize',14)              % add rmse to plot

legend('original', 'simulation');
xlabel('tick');
ylabel('fibroblast count');
hold off
drawnow

numFiles=dir(['/Users/stephaniekhuu/Documents/MATLAB/optimisationFigs' '/*.png']);
figNumber = string(size(numFiles,1));
figFileName = strcat('/Users/stephaniekhuu/Documents/MATLAB/optimisationFigs/figure',figNumber);
saveas(gcf,figFileName,'png');

close();

%% print out coefficients
disp(X);  %display coefficients
disp(rmse); %display RMSE
dlmwrite('/Users/stephaniekhuu/Documents/MATLAB/tabledata.txt',rmse,'-append'); %append RMSE

catch
   warning('Problem using function.  Assigning a value of 1000000.');   
                                            %if simulation fails, assign
                                            %large RMSE, do not use those
                                            %parameters
    rmse = 1000000; 
end





