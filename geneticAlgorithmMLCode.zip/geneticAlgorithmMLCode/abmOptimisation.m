objfunc = @(X)runABM(X);                                                %objective function to get RMSE

initpop = [1,1,1,1,1,1,1,1,1,1,1,1,1,...
    1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0];                   %start matrix with initial values
opts = optimoptions('ga','InitialPopulationMatrix',initpop);
lb = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];   %lower bounds
ub = [1 1 1 1 1 1 1 1 1 1 1 1 1 ...
    1 1 1 1 1 1 1 1 1 1 1 1 ...
    0.5 0.5 0.5 0.5 0.5 0.5];                                           %upper bounds
[xga,fga,flga,oga] = ga(objfunc,31,[],[],[],[],lb,ub,[],opts);
