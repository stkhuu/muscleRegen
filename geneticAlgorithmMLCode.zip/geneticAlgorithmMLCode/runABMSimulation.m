%% Run ABM simulation from commandline through MATLAB

% run simulation using the batch_runner.jar and batch properties
% (simBatchProp) file for muscleRegen project.
% simBatchProp = '/Users/stephaniekhuu/Documents/muscleRegen/batch/batch_configuration.properties'
function run = runABMSimulation() 

    filename = '/Users/stephaniekhuu/Documents/muscleRegen/output/Fibroblast/Data.txt';
    
    if isfile(filename)
        delete (filename);
        disp('file deleted')
    else 
        disp('no files present')
    end
% run (-r) batch simulation headless (-hl), -c,--batch_config <arg>
% location of the batch configuration file (only with -hl option). Full
% command should be in format e.g.
% java -jar batch_runner.jar -hl -r -c sample_batch_configuration.properties

    s1 = 'java -jar /Applications/Repast*\Simphony*\2.7.0/batch_runner.jar -hl -r -c ';  
    s2 = '/Users/stephaniekhuu/Documents/muscleRegen/batch/batch_configuration.properties';
    s= strcat(s1,s2);
    
% run through MATLAB environment and echo batch output
    run = system(s); 
    
end