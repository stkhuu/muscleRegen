
%% Retrieve cell count data from ABM simulation end point
function [dataset, data, dataPoints, goldData, rmse] = retrieveOutputData() % get dataset(subset) and data (all original output)
    
    goldData = [0,13;48,14.5;168,28;672,45];
    
    delimiterIn = ",";  % delimiter for data is ','
    headerslinesIn = 1; % header on line 1
    filename= '/Users/stephaniekhuu/Documents/muscleRegen/output/Fibroblast/Data.txt';

%     filename = strcat(directory, 'Fibroblast.2021.Sep.27.17_22_48.txt');
    
    data = importdata(filename,delimiterIn,headerslinesIn); % import data from filename
    dataset = data.data(:,4); % create subset of data for cell counts (column 2)
    
    dataPoints(:,3) = [dataset(1,1);dataset(48,1);dataset(168,1);dataset(672,1)];%comparison data
    dataPoints(:,1:2) = goldData; % time steps (1,48,168,672) in first column and gold data in 2
    
    rmse = sqrt(mean((dataPoints(:,2)-dataPoints(:,3)).^2));
    
end